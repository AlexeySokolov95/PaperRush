﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Class;

//Two stage: central and lateral obstacles.
enum RhombCorridorStage { Central, Lateral }
public class RhombCorridorScript : LevelBlock
{
    public int numberOfStages = 6;
    public float distanceBeetwenStage = 20.0f;
    public float centralObstacleWidth = 0.6f;
    public float lateralObstacleWidth = 0.3f;
    public float obstacleThickness = 0.5f;
    private RhombCorridorStage rhombStage = RhombCorridorStage.Central;

    void Start()
    {
        float blockLength = (numberOfStages - 1) * distanceBeetwenStage;
        Initialization(blockLength);
        PutWall();
        //Set scales of obstacles
        GameObject centralObstacle = Instantiate(Resources.Load("pref_RhombObstacle", typeof(GameObject)) as GameObject);
        centralObstacle.transform.localScale = new Vector3(centralObstacleWidth * widthWall, heightWall, obstacleThickness);
        GameObject lateralObstacle = Instantiate(Resources.Load("pref_RhombObstacle", typeof(GameObject)) as GameObject);
        lateralObstacle.transform.localScale = new Vector3(lateralObstacleWidth * widthWall, heightWall, obstacleThickness);
        //Put obstacles on the level
        float currentObstaclesZCoordinate = 0;
        while(currentObstaclesZCoordinate <= blockLength)
        {
            if(rhombStage == RhombCorridorStage.Central)
            {
                GameObject newCentralObstacle = Instantiate(centralObstacle) as GameObject;
                float yCoordinatesOfObstacle = newCentralObstacle.transform.localScale.y / 2;
                float zCoordinatesOfObstacle = zCoordinateBeginningOfBlock + currentObstaclesZCoordinate;
                newCentralObstacle.transform.position = new Vector3(0, yCoordinatesOfObstacle, zCoordinatesOfObstacle);
                
                rhombStage = RhombCorridorStage.Lateral;
            }
            else
            {
                //Put left obstacle of lateral stage
                GameObject leftObstacle = Instantiate(lateralObstacle) as GameObject;
                float xCoordinatesOfLeftObstacle =  0 - (widthWall / 2) + (lateralObstacle.transform.localScale.x  / 2);
                float yCoordinatesOfLeftObstacle = leftObstacle.transform.localScale.y / 2;
                float zCoordinatesOfLeftObstacle = zCoordinateBeginningOfBlock + currentObstaclesZCoordinate;
                leftObstacle.transform.position = new Vector3(xCoordinatesOfLeftObstacle, yCoordinatesOfLeftObstacle, 
                    zCoordinatesOfLeftObstacle);
                
                //Put right obstacle of lateral stage
                GameObject rightObstacle = Instantiate(lateralObstacle) as GameObject;
                float xCoordinatesOfRightObstacle = 0 + (widthWall / 2) - (lateralObstacle.transform.localScale.x / 2);
                float yCoordinatesOfRightObstacle = rightObstacle.transform.localScale.y / 2;
                float zCoordinatesOfRightObstacle = zCoordinateBeginningOfBlock + currentObstaclesZCoordinate;
                rightObstacle.transform.position = new Vector3(xCoordinatesOfRightObstacle, yCoordinatesOfRightObstacle,
                    zCoordinatesOfRightObstacle);
                
                rhombStage = RhombCorridorStage.Central;
            }
            currentObstaclesZCoordinate += distanceBeetwenStage;
        }
        Destroy(centralObstacle);
        Destroy(lateralObstacle);
        PutClimbBonus();
    }

    void Update()
    {

    }
    protected override void PutClimbBonus()
    {
        //Initialization of climb bonus.
        GameObject climbBonus = Instantiate(Resources.Load("bns_Climb1", typeof(GameObject)) as GameObject);
        //Search place for a bonus
        /*(switch (climbPlace)
        {
            case ClimbBonusPlace.LeftObstacle:
                break;
            case ClimbBonusPlace.RightObstacle:
                break;
            case ClimbBonusPlace.CentralObstacle:
                break;
        }*/
        int centralStages = numberOfStages - 2;
        int climbBonusPlace = Random.Range(1, centralStages + 1);
        if(IsOdd(climbBonusPlace))
        {
            //Put bonus on right or left Obstacle.
            Side ObstacleSide = (Side)Random.Range(0, 2);
            float numericalWidthLateralObstacle = lateralObstacleWidth * widthWall;
            if (ObstacleSide == Side.Left)
            {
                float xCoordinatesOnObstacles = Random.Range(3, numericalWidthLateralObstacle);
                float xCoordinatesOfClimbBonus = -(widthWall / 2) + xCoordinatesOnObstacles;
                float zCoordinateOfSelectedObstacles = zCoordinateBeginningOfBlock + (climbBonusPlace * distanceBeetwenStage);
                float fractionalOfHeightTriangle = 1.2f;
                float zCoordinateOfClimbBonus = zCoordinateOfSelectedObstacles - ((numericalWidthLateralObstacle - xCoordinatesOnObstacles) * fractionalOfHeightTriangle) - 3;
                climbBonus.transform.position = new Vector3(xCoordinatesOfClimbBonus, climbBonus.transform.position.y, zCoordinateOfClimbBonus);
            }
            else
            {
                float xCoordinatesOnObstacles = Random.Range(3, numericalWidthLateralObstacle);
                float xCoordinatesOfClimbBonus = +(widthWall / 2) - xCoordinatesOnObstacles;
                float zCoordinateOfSelectedObstacles = zCoordinateBeginningOfBlock + (climbBonusPlace * distanceBeetwenStage);
                float fractionalOfHeightTriangle = 1.2f;
                float zCoordinateOfClimbBonus = zCoordinateOfSelectedObstacles - ((numericalWidthLateralObstacle - xCoordinatesOnObstacles) * fractionalOfHeightTriangle) - 3;                
                climbBonus.transform.position = new Vector3(xCoordinatesOfClimbBonus, climbBonus.transform.position.y, zCoordinateOfClimbBonus);
            }
        }
        else
        {
            float numericalWidthCentralObstacle = centralObstacleWidth * widthWall;
            float fractionalPartOfWidthCentralObstacleForClimbBonus = 0.6f;
            float numericalPartOfWidthCentralObstacleForClimbBonus = numericalWidthCentralObstacle * fractionalPartOfWidthCentralObstacleForClimbBonus;
            float xCoordinatesOfClimbBonus = Random.Range(0, numericalWidthCentralObstacle) - (numericalWidthCentralObstacle / 2);
            float zCoordinateOfSelectedObstacles = zCoordinateBeginningOfBlock + (climbBonusPlace * distanceBeetwenStage);
            float fractionalOfHeightTriangle = 0.5f;
            float minDistanceFromObstacle = 3;
            float zCoordinateOfClimbBonus = zCoordinateOfSelectedObstacles - ((numericalWidthCentralObstacle - Mathf.Abs(xCoordinatesOfClimbBonus)) * fractionalOfHeightTriangle) - minDistanceFromObstacle;
            climbBonus.transform.position = new Vector3(xCoordinatesOfClimbBonus, climbBonus.transform.position.y, zCoordinateOfClimbBonus);
        }
        elements.Add(climbBonus);
    }
    private bool IsOdd(int number)
    {
        bool answer = false;
        if (number % 2 != 0)
            answer = true;
        return answer;
    }
}

