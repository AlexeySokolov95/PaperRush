﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Class;
using Assets.Scripts;

public class LevelCreater : MonoBehaviour
{
    [SerializeField]
    List<LevelBlock> Level = new List<LevelBlock>();

    public int numberOfCylinder = 5;
    public float cylinderMaxRandomWidthPart = 1;

    public GameObject player;
    private float length = 0;
    private float _playerPositionZ;
    public float widthWall = 50;
    public float heightWall = 30;
    private bool putRandomBlocks = true;
    private bool putClimbBonusForSmallBlock = false;
    private NextBlock nextBlock = NextBlock.Any;
    private CylinderWall cylinderWall;
    public void AddLength(float inc)
    {
        length = length + inc;
    }
    public float Length
    {
        get { return length; }
    }
    public float WidthWall
    {
        get { return widthWall; }
    }
    public float HeightWall
    {
        get { return heightWall; }
    }
    public float LevelXPosition
    {
        get { return length; }
    }
    public bool PutClimbBonus
    {
        get { return putClimbBonusForSmallBlock; }
    }
    /*private float LevelLength
    {
        get
        {
            float lentgh = 0f;
            foreach (var block in Level)
                lentgh += block.length;
            return lentgh;
        }
    }*/
    delegate void BlockCreater(LevelBlock block);

    void Start()
    {
        // Application.LoadLevel("Scene1");
        Instantiate(Resources.Load("StartBlock", typeof(GameObject)) as GameObject);
        AddLength(75);
        if (!putRandomBlocks)
            LoadAllBlocks();
        cylinderWall = new CylinderWall(0, numberOfCylinder, widthWall, heightWall, cylinderMaxRandomWidthPart);
        /*GameObject startBlock1 = Instantiate(wallPrefab) as GameObject;
        startBlock1.transform.position = new Vector3(levelXPosition, 0, 0);
        Level.Add(startBlock1);
        GameObject startBlock2 = Instantiate(wallPrefab) as GameObject;
        startBlock1.transform.position = new Vector3(levelXPosition, 0, 100);
        Level.Add(startBlock2); */
    }


    // Update is called once per frame
    void Update()
    {
        if (putRandomBlocks)
        {
            _playerPositionZ = player.transform.position.z;
            float endOfLevel = length;
            if (endOfLevel - _playerPositionZ < 300)
            {
                CreateNewBlock(endOfLevel);
            }
        }
        if (_playerPositionZ + 250 > cylinderWall.CurentWallLength)
            cylinderWall.Put();
    }
    private void CreateNewBlock(float endOfLevel)
    {
        GameObject newBlock = SelectNewBlock1(endOfLevel);
        Instantiate(newBlock);
    }
    /*
    private GameObject SelectNewBlock(float startPosition)
    {
        float number = Random.Range(0, 8);
        GameObject newBlock = Resources.Load("SpikeWall 1", typeof(GameObject)) as GameObject;
        do
        {
            //newBlock = Resources.Load("ZigZagBlock2", typeof(GameObject)) as GameObject; //Сомнительная херня
            newBlock = Resources.Load("DiagonalWallBlock", typeof(GameObject)) as GameObject;
            
                if (number > 8 )
            {
                //newBlock = Resources.Load("CrackInWallBlock", typeof(GameObject)) as GameObject;
                break;
            }

            if (number > 7)
            {
                newBlock = Resources.Load("ZigZagBlock2", typeof(GameObject)) as GameObject;
                break;
            }
            if (number > 6)
            {
                newBlock = Resources.Load("ForestOfSpike", typeof(GameObject)) as GameObject;
                break;
            }
            if (number > 5)
            {
                newBlock = Resources.Load("DancingSpikesBlock", typeof(GameObject)) as GameObject;
                break;
            }
            if (number > 4)
            {
                newBlock = Resources.Load("ChessSpikesBlock", typeof(GameObject)) as GameObject;
                break;
            }
            if (number > 3)
            {
                newBlock = Resources.Load("MovingSpikesBlock", typeof(GameObject)) as GameObject;
                break;
            }
            
            if (number > 2)
            {
                newBlock = Resources.Load("RhombCorridorBlock", typeof(GameObject)) as GameObject;
                break;
            }
            

        }
        while (!true);
        return newBlock;
    }
    */
    private GameObject SelectNewBlock1(float startPosition)
    {
        GameObject newBlock = Resources.Load("DiagonalWallBlock", typeof(GameObject)) as GameObject;
        if (nextBlock == NextBlock.Any)
        {
            putClimbBonusForSmallBlock = false;
            int blockNumber = Random.Range(1, 9);
            switch (blockNumber)
            {
                case 1:
                    newBlock = Resources.Load("ClosingWallBlock", typeof(GameObject)) as GameObject;
                    nextBlock = NextBlock.Any;
                    break;
                case 2:
                    newBlock = Resources.Load("BlocksWallBlock", typeof(GameObject)) as GameObject;
                    nextBlock = NextBlock.Any;
                    break;
                case 3:
                    newBlock = Resources.Load("RhombCorridorBlock", typeof(GameObject)) as GameObject;
                    nextBlock = NextBlock.Any;
                    break;
                case 4:
                    newBlock = Resources.Load("CrackInWallBlock", typeof(GameObject)) as GameObject;
                    nextBlock = NextBlock.Any;
                    break;
                case 5:
                    newBlock = Resources.Load("MovingOnePillarBlock", typeof(GameObject)) as GameObject;
                    nextBlock = NextBlock.SmallBlockWithClimbBonus;
                    break;
                case 6:
                    newBlock = Resources.Load("SeveralMovingPillarBlock", typeof(GameObject)) as GameObject;
                    nextBlock = NextBlock.SmallBlockWithClimbBonus;
                    break;
                case 7:
                    newBlock = Resources.Load("DiagonalWallBlock", typeof(GameObject)) as GameObject;
                    nextBlock = NextBlock.Any;
                    break;
                case 8:
                    newBlock = Resources.Load("ZigZagBlock2", typeof(GameObject)) as GameObject;
                    nextBlock = NextBlock.Any;
                    break;
            }
        }
        else if (nextBlock == NextBlock.SmallBlockWithClimbBonus)
        {
            putClimbBonusForSmallBlock = true;
            int blockNumber = Random.Range(1, 4);
            switch (blockNumber)
            {
                case 1:
                    newBlock = Resources.Load("ClosingWallBlock", typeof(GameObject)) as GameObject;
                    nextBlock = NextBlock.Any;
                    break;
                case 2:
                    newBlock = Resources.Load("BlocksWallBlock", typeof(GameObject)) as GameObject;
                    nextBlock = NextBlock.Any;
                    break;
                case 3:
                    newBlock = Resources.Load("DiagonalWallBlock", typeof(GameObject)) as GameObject;
                    nextBlock = NextBlock.Any;
                    break;
            }
        }
        //newBlock = Resources.Load("ZigZagBlock2", typeof(GameObject)) as GameObject;
        return newBlock;
    }
    private void LoadAllBlocks()
    {
        List<GameObject> allBlocks = AllBlocks();
        for (int i = 0; i < allBlocks.Count; i++)
        {
            Instantiate(allBlocks[i]);
            for (int j = 0; j < allBlocks.Count; j++)
                Instantiate(allBlocks[j]);
        }
    }
    private List<GameObject> AllBlocks()
    {
        List<GameObject> allBlocks = new List<GameObject>() {
            /*Resources.Load("SpikeWall 1",typeof(GameObject)) as GameObject,*/
            Resources.Load("CrackInWallBlock", typeof(GameObject)) as GameObject,
            Resources.Load("ZigZagBlock2", typeof(GameObject)) as GameObject,
            Resources.Load("ForestOfSpike", typeof(GameObject)) as GameObject,
            Resources.Load("DancingSpikesBlock", typeof(GameObject)) as GameObject,
            Resources.Load("ChessSpikesBlock", typeof(GameObject)) as GameObject,
            Resources.Load("MovingSpikesBlock", typeof(GameObject)) as GameObject };
        return allBlocks;
    }
    /*private void CrackInWall(LevelBlock block)
    {
        float distanceBetweenWalls = 20f;
        block.walls = Instantiate(wallPrefab) as GameObject;
        block.length = 100f;
        block.walls.transform.position = new Vector3(levelXPosition, 0, block.startPosition);
        float positionZNewWall = 0f;
        float widthWall = 50f;
        float heightWall = 15f;
        float heightBlock = 25f;
        while (positionZNewWall < 100)
        {
            GameObject crackWall1 = Instantiate(Resources.Load("prefCrackWall", typeof(GameObject))) as GameObject;
            GameObject crackWall2 = Instantiate(Resources.Load("prefCrackWall", typeof(GameObject))) as GameObject;
            crackWall1.transform.position = new Vector3(levelXPosition - widthWall + 1.01f, heightWall / 2, block.startPosition + positionZNewWall - (block.length / 2));
            crackWall2.transform.position = new Vector3(levelXPosition + widthWall - 1.01f, heightWall / 2, block.startPosition + positionZNewWall - (block.length / 2));
            StartCoroutine(CloseCrackInWall(FindStartTime(positionZNewWall)));
        }

    }
    private IEnumerator CloseCrackInWall(float startTime)
    {
        yield return new WaitForSeconds(startTime);
        

    }
    private float FindStartTime(float positionZNewWall)
    {
        return 0f;
    }
    */
}
enum NextBlock { Any, SmallBlockWithClimbBonus}

