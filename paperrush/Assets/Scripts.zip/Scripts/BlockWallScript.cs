﻿using UnityEngine;
using Assets.Class;
using DG.Tweening;

public class BlockWallScript : LevelBlock, IWithClimbBonus
{
    public int numberBlocks = 3;
    public float passageWidth = 4;
    public float movingDuration = 1;
    public float areaMoving = 15;
    public float blockLength = 25;
    private float blockWallBlockScaleX;
    private GameObject[] blocks;
    void Start()
    {
        Initialization(blockLength);
        PutWall();
        blocks = new GameObject[numberBlocks];
        GameObject block = Instantiate(Resources.Load("pref_BlockWallBlock", typeof(GameObject))) as GameObject;
        blockWallBlockScaleX = (widthWall - ((numberBlocks - 1) * passageWidth)) / 3;
        block.transform.localScale = new Vector3(blockWallBlockScaleX, heightWall, blockWallBlockScaleX);
        float distantPosition = zCoordinateBeginningOfBlock + (blockLength / 2) + (areaMoving / 2);
        float nearPosition = zCoordinateBeginningOfBlock + (blockLength / 2) - (areaMoving / 2);
        for (int i = 0; i < numberBlocks; i++)
        {
            float positionX = (-widthWall / 2) + (blockWallBlockScaleX / 2) + (passageWidth * i) + (blockWallBlockScaleX * i);
            GameObject newBlock = Instantiate(block);
            if (i % 2 == 0)
            {

                newBlock.transform.position = new Vector3(positionX, heightWall / 2, distantPosition);
                Sequence newBlockSequence = DOTween.Sequence();
                newBlockSequence.Append(newBlock.transform.DOMoveZ(nearPosition, movingDuration, false));
                newBlockSequence.Append(newBlock.transform.DOMoveZ(distantPosition, movingDuration, false));
                newBlockSequence.SetLoops(-1, LoopType.Restart).SetEase(Ease.Linear);
            }
            else
            {
                newBlock.transform.position = new Vector3(positionX, heightWall / 2, nearPosition);
                Sequence newBlockSequence = DOTween.Sequence();
                newBlockSequence.Append(newBlock.transform.DOMoveZ(distantPosition, movingDuration, false));
                newBlockSequence.Append(newBlock.transform.DOMoveZ(nearPosition, movingDuration, false));
                newBlockSequence.SetLoops(-1, LoopType.Restart).SetEase(Ease.Linear);
            }
            
        }
        if (LevelManager.PutClimbBonus)
            PutClimbBonus();
        Destroy(block);
    }


    void Update()
    {

    }
    public void PutClimbBonus()
    {
        ClimbBonusPositionOnBlockWall position = (ClimbBonusPositionOnBlockWall)Random.Range(1,3);
        GameObject climbBonus = Instantiate(Resources.Load("bns_Climb1", typeof(GameObject)) as GameObject);
        if (position == ClimbBonusPositionOnBlockWall.BeforeBlocks)
        {           
            float distanceFromObstacle = 10;
            float distantZPosition = zCoordinateBeginningOfBlock + (blockLength / 2 - (areaMoving / 2)) - distanceFromObstacle;
            float nearZPosisition = zCoordinateBeginningOfBlock;
            float climbBonusZPosition = Random.Range(nearZPosisition, distantZPosition);
            float distanceFromWall = 3;
            float climbBonusXPosition = Random.Range((-widthWall / 2) + distanceFromWall, (widthWall / 2) - distanceFromWall);
            climbBonus.transform.position = new Vector3(climbBonusXPosition, climbBonus.transform.position.y, climbBonusZPosition);
        }
        else
        { 
            int numberOfPassage = Random.Range(0, numberBlocks - 1);
            float centrXPositionOfPassage = (-widthWall / 2) + blockWallBlockScaleX + (passageWidth / 2) + ((blockWallBlockScaleX + passageWidth) * numberOfPassage);
            float distantZPositionClimbBonus = zCoordinateBeginningOfBlock + (blockLength / 2) + (areaMoving / 2);
            float nearZPositionClimbBonus = zCoordinateBeginningOfBlock + (blockLength / 2) - (areaMoving / 2);
            float climbBonusZPosition = Random.Range(nearZPositionClimbBonus, nearZPositionClimbBonus);
            climbBonus.transform.position = new Vector3(centrXPositionOfPassage, climbBonus.transform.position.y, climbBonusZPosition);
       }
    }
}
enum ClimbBonusPositionOnBlockWall {BeforeBlocks, BeetwenBlocks }

