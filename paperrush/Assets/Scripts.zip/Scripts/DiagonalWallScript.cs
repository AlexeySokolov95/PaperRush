﻿using UnityEngine;
using Assets.Class;

public class DiagonalWallScript : LevelBlock, IWithClimbBonus
{
    public int numberOfBlocks  = 5;
    public int blocksForExit = 1;
    private Side exitSide;

    void Start()
    {
        float blockLength = 20;
        Initialization(blockLength);
        PutWall();
        GameObject zigBlock = Instantiate(Resources.Load("pref_ZigWallBlock", typeof(GameObject))) as GameObject;
        zigBlock.transform.localScale = new Vector3(widthWall / numberOfBlocks, heightWall, widthWall / numberOfBlocks);
        exitSide = (Side)Random.Range(0, 2);
        for (int blockNumber = 1; blockNumber <= numberOfBlocks - blocksForExit; blockNumber++)
        {
            PutBlock(zigBlock, blockNumber);
        }
        if (LevelManager.PutClimbBonus)
            PutClimbBonus();
    }
    void PutBlock(GameObject zigBlock, int blockNumber)
    {
        float xPosition;        
        if (exitSide == Side.Right)
            xPosition = -(widthWall / 2) + (widthWall / (numberOfBlocks * 2)) + ((widthWall / numberOfBlocks) * (blockNumber - 1));
        else
            xPosition = (widthWall / 2) - ((widthWall / (numberOfBlocks * 2)) + ((widthWall / numberOfBlocks) * (blockNumber - 1)));
        float yPosition = heightWall / 2;
        float zPosition = zCoordinateBeginningOfBlock + (widthWall / (numberOfBlocks * 2)) + ((widthWall / numberOfBlocks) * (blockNumber - 1));
        zigBlock.transform.position = new Vector3(xPosition, yPosition, zPosition);
        GameObject newZigBlock = Instantiate(zigBlock) as GameObject;
    }
    
    public void PutClimbBonus()
    {
        GameObject climbBonus = Instantiate(Resources.Load("bns_Climb1", typeof(GameObject)) as GameObject);
        int numberOfBlock = Random.Range(1, numberOfBlocks);
        float minDistanceToBlock = 8f;
        float zPositionEdgeBlock = zCoordinateBeginningOfBlock + (widthWall / (numberOfBlocks * 2)) + ((widthWall / numberOfBlocks) * (numberOfBlock - 1)) - (widthWall / (numberOfBlocks * 2));
        float addDistanceToZposition = 2f;
        float zBonusPosition = zPositionEdgeBlock - (10f + ((numberOfBlocks - numberOfBlock) * addDistanceToZposition));
        float xBonusPosition = 0;
        if (exitSide == Side.Right)
            xBonusPosition = -(widthWall / 2) + (widthWall / (numberOfBlocks * 2)) + ((widthWall / numberOfBlocks) * (numberOfBlock - 1));
        else
            xBonusPosition = (widthWall / 2) - ((widthWall / (numberOfBlocks * 2)) + ((widthWall / numberOfBlocks) * (numberOfBlock - 1)));
        climbBonus.transform.position = new Vector3(xBonusPosition, climbBonus.transform.position.y, zBonusPosition);
    }
}
