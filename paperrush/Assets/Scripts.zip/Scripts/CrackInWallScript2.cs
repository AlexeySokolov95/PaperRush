﻿using UnityEngine;
using Assets.Class;

public class CrackInWallScript2 : LevelBlock
{
    float crackPosition;
    public int numberOfWalls = 4;
    public float distanceBetweenWalls = 30f;
    public float closingSpeed = 25f;
    public float crackWidth = 4;
    public float crackMinDistanceFromWall = 4;
    void Start()
    {
        float blockLength = (numberOfWalls - 1) * distanceBetweenWalls;
        Initialization(blockLength);
        PutWall();
        GameObject obstacleWall  = Instantiate(Resources.Load("prefCrackWall", typeof(GameObject))) as GameObject;
        obstacleWall.transform.localScale  = new Vector3(widthWall, heightWall, obstacleWall.transform.localScale.z);
        float positionZNewWall = 0f;
        while (positionZNewWall <= blockLength)
        {
            crackPosition = Random.Range((-widthWall / 2) + crackMinDistanceFromWall, (widthWall / 2) - crackMinDistanceFromWall);
            GameObject leftObstacle  = Instantiate(obstacleWall) as GameObject;
            GameObject rightObstacle = Instantiate(obstacleWall) as GameObject;
            leftObstacle.transform.position  = new Vector3(-(widthWall / 2) + crackPosition - (crackWidth / 2), heightWall / 2, zCoordinateBeginningOfBlock + positionZNewWall);
            rightObstacle.transform.position = new Vector3((widthWall / 2) + crackPosition + (crackWidth / 2), heightWall / 2, zCoordinateBeginningOfBlock + positionZNewWall);
            positionZNewWall = positionZNewWall + distanceBetweenWalls;
        }
        Destroy(obstacleWall);
        PutClimbBonus();
    }
    void Update()
    {
        
    }
    protected override void PutClimbBonus()
    {
        GameObject climbBonus = Instantiate(Resources.Load("bns_Climb1", typeof(GameObject)) as GameObject);
        int centralWalls = numberOfWalls - 2;
        int climbBonusPlace = Random.Range(1, centralWalls + 1);
        //Сhoose between the right and left wall.
        Side selectedWallSide = (Side)Random.Range(0, 2);
        if (selectedWallSide == Side.Left)
        {
            float widthLeftCrackWall = (widthWall / 2) + crackPosition - (crackWidth / 2);
            float xCoordinatesOnWall = Random.Range(crackMinDistanceFromWall, widthLeftCrackWall);
            float xCoordinatesOfClimbBonus = -(widthWall / 2) + xCoordinatesOnWall;
            float zCoordinateOfSelectedObstacles = zCoordinateBeginningOfBlock + (climbBonusPlace * distanceBetweenWalls);
            float fractionalOfHeightTriangle = 0.25f;
            float zDistanceFromObstacle = distanceBetweenWalls * 0.4f;
            float zCoordinateOfClimbBonus = zCoordinateOfSelectedObstacles - ((widthLeftCrackWall - xCoordinatesOnWall) * fractionalOfHeightTriangle) - zDistanceFromObstacle;
            climbBonus.transform.position = new Vector3(xCoordinatesOfClimbBonus, climbBonus.transform.position.y, zCoordinateOfClimbBonus);
        }
        else if (selectedWallSide == Side.Right)
        {
            float widthRightCrackWall = (widthWall / 2) + crackPosition + (crackWidth / 2);
            float xCoordinatesOnWall = Random.Range(crackMinDistanceFromWall, widthRightCrackWall);
            float xCoordinatesOfClimbBonus = +(widthWall / 2) - xCoordinatesOnWall;
            float zCoordinateOfSelectedObstacles = zCoordinateBeginningOfBlock + (climbBonusPlace * distanceBetweenWalls);
            float fractionalOfHeightTriangle = 0.5f;
            float zDistanceFromObstacle = distanceBetweenWalls * 0.4f;
            float zCoordinateOfClimbBonus = zCoordinateOfSelectedObstacles - ((widthRightCrackWall - xCoordinatesOnWall) * fractionalOfHeightTriangle) - zDistanceFromObstacle;
            climbBonus.transform.position = new Vector3(xCoordinatesOfClimbBonus, climbBonus.transform.position.y, zCoordinateOfClimbBonus);
        }
    }
}
