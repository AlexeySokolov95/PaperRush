﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMoving : MonoBehaviour
{
    public float cameraZ = -7.5f;
    public float cameraY = 5.6f;
    public float playerXSpeed = 1.7f;
    private GameObject player;
    // Use this for initialization
    void Start()
    {
        player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void LateUpdate()
    {
        float posX = player.transform.position.x / playerXSpeed;
        float posY = player.transform.position.y + cameraY;
        float posZ = player.transform.position.z + cameraZ;
        transform.position = new Vector3(posX, posY, posZ);
    }
}
