﻿using System;
using UnityEngine;
using UnityEngine.UI;

public class UIController : MonoBehaviour
{
    [SerializeField]
    private Text scoreLabel;
    public GameObject player;

    void Start()
    {
        scoreLabel.color = Color.black;
        scoreLabel.text = "0";
    }

    void Update()
    {
        scoreLabel.text = Math.Round(player.transform.position.z / 50).ToString();
    }
}
